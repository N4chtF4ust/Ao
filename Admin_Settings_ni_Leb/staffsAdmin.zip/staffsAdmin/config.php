<?php
// Database connection configuration
$host = "localhost";  
$user = "root";       
$pass = "";           
$dbname = "staffs";   

// Connection
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Check
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


?>